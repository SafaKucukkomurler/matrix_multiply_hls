// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xmatrix_multiply.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMatrix_multiply_CfgInitialize(XMatrix_multiply *InstancePtr, XMatrix_multiply_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Data_BaseAddress = ConfigPtr->Data_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMatrix_multiply_Start(XMatrix_multiply *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatrix_multiply_ReadReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_AP_CTRL) & 0x80;
    XMatrix_multiply_WriteReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMatrix_multiply_IsDone(XMatrix_multiply *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatrix_multiply_ReadReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMatrix_multiply_IsIdle(XMatrix_multiply *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatrix_multiply_ReadReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMatrix_multiply_IsReady(XMatrix_multiply *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatrix_multiply_ReadReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMatrix_multiply_EnableAutoRestart(XMatrix_multiply *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatrix_multiply_WriteReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_AP_CTRL, 0x80);
}

void XMatrix_multiply_DisableAutoRestart(XMatrix_multiply *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatrix_multiply_WriteReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_AP_CTRL, 0);
}

u32 XMatrix_multiply_Get_A_BaseAddress(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_A_BASE);
}

u32 XMatrix_multiply_Get_A_HighAddress(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_A_HIGH);
}

u32 XMatrix_multiply_Get_A_TotalBytes(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XMATRIX_MULTIPLY_DATA_ADDR_A_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_A_BASE + 1);
}

u32 XMatrix_multiply_Get_A_BitWidth(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMATRIX_MULTIPLY_DATA_WIDTH_A;
}

u32 XMatrix_multiply_Get_A_Depth(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMATRIX_MULTIPLY_DATA_DEPTH_A;
}

u32 XMatrix_multiply_Write_A_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMATRIX_MULTIPLY_DATA_ADDR_A_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_A_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_A_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XMatrix_multiply_Read_A_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMATRIX_MULTIPLY_DATA_ADDR_A_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_A_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_A_BASE + (offset + i)*4);
    }
    return length;
}

u32 XMatrix_multiply_Write_A_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMATRIX_MULTIPLY_DATA_ADDR_A_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_A_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_A_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XMatrix_multiply_Read_A_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMATRIX_MULTIPLY_DATA_ADDR_A_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_A_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_A_BASE + offset + i);
    }
    return length;
}

u32 XMatrix_multiply_Get_B_BaseAddress(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_B_BASE);
}

u32 XMatrix_multiply_Get_B_HighAddress(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_B_HIGH);
}

u32 XMatrix_multiply_Get_B_TotalBytes(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XMATRIX_MULTIPLY_DATA_ADDR_B_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_B_BASE + 1);
}

u32 XMatrix_multiply_Get_B_BitWidth(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMATRIX_MULTIPLY_DATA_WIDTH_B;
}

u32 XMatrix_multiply_Get_B_Depth(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMATRIX_MULTIPLY_DATA_DEPTH_B;
}

u32 XMatrix_multiply_Write_B_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMATRIX_MULTIPLY_DATA_ADDR_B_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_B_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_B_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XMatrix_multiply_Read_B_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMATRIX_MULTIPLY_DATA_ADDR_B_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_B_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_B_BASE + (offset + i)*4);
    }
    return length;
}

u32 XMatrix_multiply_Write_B_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMATRIX_MULTIPLY_DATA_ADDR_B_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_B_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_B_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XMatrix_multiply_Read_B_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMATRIX_MULTIPLY_DATA_ADDR_B_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_B_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_B_BASE + offset + i);
    }
    return length;
}

u32 XMatrix_multiply_Get_C_BaseAddress(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_C_BASE);
}

u32 XMatrix_multiply_Get_C_HighAddress(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_C_HIGH);
}

u32 XMatrix_multiply_Get_C_TotalBytes(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XMATRIX_MULTIPLY_DATA_ADDR_C_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_C_BASE + 1);
}

u32 XMatrix_multiply_Get_C_BitWidth(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMATRIX_MULTIPLY_DATA_WIDTH_C;
}

u32 XMatrix_multiply_Get_C_Depth(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMATRIX_MULTIPLY_DATA_DEPTH_C;
}

u32 XMatrix_multiply_Write_C_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMATRIX_MULTIPLY_DATA_ADDR_C_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_C_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_C_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XMatrix_multiply_Read_C_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMATRIX_MULTIPLY_DATA_ADDR_C_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_C_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_C_BASE + (offset + i)*4);
    }
    return length;
}

u32 XMatrix_multiply_Write_C_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMATRIX_MULTIPLY_DATA_ADDR_C_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_C_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_C_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XMatrix_multiply_Read_C_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMATRIX_MULTIPLY_DATA_ADDR_C_HIGH - XMATRIX_MULTIPLY_DATA_ADDR_C_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Data_BaseAddress + XMATRIX_MULTIPLY_DATA_ADDR_C_BASE + offset + i);
    }
    return length;
}

void XMatrix_multiply_InterruptGlobalEnable(XMatrix_multiply *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatrix_multiply_WriteReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_GIE, 1);
}

void XMatrix_multiply_InterruptGlobalDisable(XMatrix_multiply *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatrix_multiply_WriteReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_GIE, 0);
}

void XMatrix_multiply_InterruptEnable(XMatrix_multiply *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMatrix_multiply_ReadReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_IER);
    XMatrix_multiply_WriteReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_IER, Register | Mask);
}

void XMatrix_multiply_InterruptDisable(XMatrix_multiply *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMatrix_multiply_ReadReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_IER);
    XMatrix_multiply_WriteReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_IER, Register & (~Mask));
}

void XMatrix_multiply_InterruptClear(XMatrix_multiply *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatrix_multiply_WriteReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_ISR, Mask);
}

u32 XMatrix_multiply_InterruptGetEnabled(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMatrix_multiply_ReadReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_IER);
}

u32 XMatrix_multiply_InterruptGetStatus(XMatrix_multiply *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMatrix_multiply_ReadReg(InstancePtr->Data_BaseAddress, XMATRIX_MULTIPLY_DATA_ADDR_ISR);
}

