// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XMATRIX_MULTIPLY_H
#define XMATRIX_MULTIPLY_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmatrix_multiply_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Data_BaseAddress;
} XMatrix_multiply_Config;
#endif

typedef struct {
    u32 Data_BaseAddress;
    u32 IsReady;
} XMatrix_multiply;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMatrix_multiply_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMatrix_multiply_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMatrix_multiply_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMatrix_multiply_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XMatrix_multiply_Initialize(XMatrix_multiply *InstancePtr, u16 DeviceId);
XMatrix_multiply_Config* XMatrix_multiply_LookupConfig(u16 DeviceId);
int XMatrix_multiply_CfgInitialize(XMatrix_multiply *InstancePtr, XMatrix_multiply_Config *ConfigPtr);
#else
int XMatrix_multiply_Initialize(XMatrix_multiply *InstancePtr, const char* InstanceName);
int XMatrix_multiply_Release(XMatrix_multiply *InstancePtr);
#endif

void XMatrix_multiply_Start(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_IsDone(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_IsIdle(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_IsReady(XMatrix_multiply *InstancePtr);
void XMatrix_multiply_EnableAutoRestart(XMatrix_multiply *InstancePtr);
void XMatrix_multiply_DisableAutoRestart(XMatrix_multiply *InstancePtr);

u32 XMatrix_multiply_Get_A_BaseAddress(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_A_HighAddress(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_A_TotalBytes(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_A_BitWidth(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_A_Depth(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Write_A_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length);
u32 XMatrix_multiply_Read_A_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length);
u32 XMatrix_multiply_Write_A_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length);
u32 XMatrix_multiply_Read_A_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length);
u32 XMatrix_multiply_Get_B_BaseAddress(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_B_HighAddress(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_B_TotalBytes(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_B_BitWidth(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_B_Depth(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Write_B_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length);
u32 XMatrix_multiply_Read_B_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length);
u32 XMatrix_multiply_Write_B_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length);
u32 XMatrix_multiply_Read_B_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length);
u32 XMatrix_multiply_Get_C_BaseAddress(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_C_HighAddress(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_C_TotalBytes(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_C_BitWidth(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Get_C_Depth(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_Write_C_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length);
u32 XMatrix_multiply_Read_C_Words(XMatrix_multiply *InstancePtr, int offset, word_type *data, int length);
u32 XMatrix_multiply_Write_C_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length);
u32 XMatrix_multiply_Read_C_Bytes(XMatrix_multiply *InstancePtr, int offset, char *data, int length);

void XMatrix_multiply_InterruptGlobalEnable(XMatrix_multiply *InstancePtr);
void XMatrix_multiply_InterruptGlobalDisable(XMatrix_multiply *InstancePtr);
void XMatrix_multiply_InterruptEnable(XMatrix_multiply *InstancePtr, u32 Mask);
void XMatrix_multiply_InterruptDisable(XMatrix_multiply *InstancePtr, u32 Mask);
void XMatrix_multiply_InterruptClear(XMatrix_multiply *InstancePtr, u32 Mask);
u32 XMatrix_multiply_InterruptGetEnabled(XMatrix_multiply *InstancePtr);
u32 XMatrix_multiply_InterruptGetStatus(XMatrix_multiply *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
